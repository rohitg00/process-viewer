"""
Process Viewer - A terminal-based process visualization tool.
"""

__version__ = "0.1.0"
